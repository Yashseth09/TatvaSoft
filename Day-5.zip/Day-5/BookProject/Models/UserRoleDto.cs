﻿namespace BookProject.Models
{
    public class UserRoleDto
    {
        public string Username { get; set; }
        public string RoleName { get; set; }
    }
}
