﻿namespace BookProject.Models
{
    public class UserNew
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string Role { get; set; }
    }
}
