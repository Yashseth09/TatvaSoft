namespace BookProject.Models
{
    public class UserRoleDto
    {
        public string UserName { get; set; }
        public string RoleName { get; set; }
    }
}